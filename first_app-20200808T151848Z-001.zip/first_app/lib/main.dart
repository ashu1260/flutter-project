import 'package:flutter/material.dart';
import'./ui/home.dart';
import'./ui/secondpage.dart';
//import'./ui/thirdpage.dart';
import'./ui/forthpage.dart';
//import'./ui/fifthp.dart';
void main(){ runApp(MyApp());

}
 
class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) 
  {
    return MaterialApp(
    home: Homepage(), 
    routes: <String, WidgetBuilder>{
     "/secondpage": (context) => Secondpage(),
     "/forthpage":  (context) => Forthp(),
      //"/fifthpage": (context) => Fifthp(),
       

    }, 
    );
  }
}
 






  







           
   


  




      
           
          


