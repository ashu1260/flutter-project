import 'package:flutter/material.dart';
import 'package:flutter_signin_button/flutter_signin_button.dart';

String _radioValue; //Initial definition of radio button value
  String choice;

class  Homepage extends StatelessWidget {
   @override
   Widget build(BuildContext context) {
     return new Scaffold(
       appBar: AppBar(title: Text("Home"),
        backgroundColor: Colors.black,
        ),
        backgroundColor: Colors.blueGrey,
        body:Column(
          children: <Widget>[
          Container(
            margin:EdgeInsets.fromLTRB(0,20,0,0),
            alignment: Alignment(0.0, 0.0),
            decoration: new BoxDecoration(
    // Circle shape
         shape: BoxShape.circle,
            //color: Colors.red,
    // The border you want
        border: new Border.all(
              width: 2.0,
            color: Colors.white,
            ),
          ),
          child: CircleAvatar(
                backgroundColor: Colors.white,
                //foregroundColor: Colors.red,
                 radius:40,
              ),
        ),
           Container(
           width:250, height:35,
           alignment: Alignment(0.0, 0.0),
           margin: EdgeInsets.fromLTRB(0,40, 0, 0),
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(100),
                  color: Colors.white,
              ),
               
              child: TextField(
                 textAlign: TextAlign.center,
                style: TextStyle(fontSize:10.0),
                 decoration: InputDecoration(
                 border: InputBorder.none,
              
                  hintText: 'Enter Your Email-id'
                  ),
              ),
           ),

         Container(
           width:250, height:35,
            alignment: Alignment(0.0, 0.0),
           margin: EdgeInsets.fromLTRB(0,15, 0, 0),
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(100),
                  color: Colors.white,
              ),
             
              child: TextField(
                textAlign: TextAlign.center,
                style: TextStyle(fontSize:10.0),
                 decoration: InputDecoration(
                 border: InputBorder.none,
                   hintText: 'Enter Password'
                ),
              ),
            ),


        Container(
           width:250, height:35,
            alignment: Alignment(0.0, 0.0),
           margin: EdgeInsets.fromLTRB(0,15, 0, 0),
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(100),
                  color: Colors.white,
              ),
             
              child: TextField(
                textAlign: TextAlign.center,
                style: TextStyle(fontSize:10.0),
                 decoration: InputDecoration(
                  border: InputBorder.none,
                   hintText: 'Confirm Password',
                ),
              ),
           ),
           Row(
            children: <Widget>[
              Padding(padding:  EdgeInsets.fromLTRB(40.0, 0, 0, 0),
                child:Radio(
                    value: 'one',
                    onChanged:null,
                   groupValue: _radioValue,
                   activeColor: Colors.white,
        
              ),
              ),
            Text("I agree all the terms and services.",
             style: TextStyle(color:Colors.black),),
              
                          
],

),

RaisedButton(
  child: SizedBox(height:20.0, width:100.0, child: Text("Sign up",
   style: TextStyle(fontSize:15.0, color: Colors.red, fontWeight:FontWeight.bold,),
    textAlign: TextAlign.center,
  ),
  ),
   onPressed: (){
    Navigator.pushNamed(context,'/secondpage');

   },
   
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0),),
    color: Colors.white ,
),

Padding(padding: EdgeInsets.fromLTRB(0,50.0,0, 0),

  child:Text("OR", style:TextStyle(color: Colors.black),
 textAlign: TextAlign.center,
 ),
),

Container(
     
      alignment: Alignment(0.0, 0.0),
      child:SignInButton(
      Buttons.Google,
      onPressed: () {},
      ///text: "signing with google",
     
),
  ),
  Container(
       alignment: Alignment(0.0, 0.0),
      child:SignInButton(
      Buttons.Facebook,
      onPressed: () {},
      ///text: "signing with google",
     
),
),

     ],
    )

);
   
}
 }        

