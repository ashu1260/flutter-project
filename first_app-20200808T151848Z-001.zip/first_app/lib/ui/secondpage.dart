import 'package:flutter/material.dart';

class  Secondpage extends StatelessWidget {
   @override
   Widget build(BuildContext context) {
     return new Scaffold(
       appBar: AppBar(title: Text("Home"),
        backgroundColor: Colors.black,
        ),
        backgroundColor: Colors.blueGrey,
        body:Column(
          children: <Widget>[
          Container(
            margin:EdgeInsets.fromLTRB(0,20,0,0),
            alignment: Alignment(0.0, 0.0),
            decoration: new BoxDecoration(
    // Circle shape
         shape: BoxShape.circle,
            //color: Colors.red,
    // The border you want
        border: new Border.all(
              width: 2.0,
            color: Colors.white,
            ),
          ),
          child: CircleAvatar(
                backgroundColor: Colors.white,
                //foregroundColor: Colors.red,
                 radius:40,
              ),
        ), 
        Padding(padding: EdgeInsets.fromLTRB(0,50.0,0, 0),
            child:Text("Welcome Back!.",
             style: TextStyle(color:Colors.black, fontSize:20),
             textAlign: TextAlign.center,
            ),
        ),

        
           Container(
           width:250, height:35,
           alignment: Alignment(0.0, 0.0),
           margin: EdgeInsets.fromLTRB(0,40, 0, 0),
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(100),
                  color: Colors.white,
              ),
               
              child: TextField(
                 textAlign: TextAlign.center,
                style: TextStyle(fontSize:10.0),
                 decoration: InputDecoration(
                 border: InputBorder.none,
              
                  hintText: 'Enter Your Email-id'
                  ),
              ),
           ),

         Container(
           width:250, height:35,
            alignment: Alignment(0.0, 0.0),
           margin: EdgeInsets.fromLTRB(0,15, 0, 0),
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(100),
                  color: Colors.white,
              ),
             
              child: TextField(
                textAlign: TextAlign.center,
                style: TextStyle(fontSize:10.0),
                 decoration: InputDecoration(
                 border: InputBorder.none,
                   hintText: 'Enter Password'
                ),
              ),
            ),

           Padding( padding: EdgeInsets.fromLTRB(0,20,0,0),
            child:RaisedButton(
              child: SizedBox(height:18.0, width:90.0, child: Text("Login",
              style: TextStyle(fontSize:15.0, color: Colors.red, fontWeight:FontWeight.bold,),
               textAlign: TextAlign.center,
             ),
            ),
           onPressed: (){
             Navigator.pushNamed(context,'/forthpage');
           },
           
           shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0),),
           color: Colors.white ,
),
),


          ],
        )
     );

   }
}