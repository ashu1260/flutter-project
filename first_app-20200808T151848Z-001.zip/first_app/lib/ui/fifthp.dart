import 'package:flutter/material.dart';
String _radioValue; //Initial definition of radio button value
  String choice;

class Fifthp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return  new Scaffold(
       appBar: AppBar(title: Text("upload files"),
        backgroundColor: Colors.black,
        ),
        
        
        
        body:Container(
          margin: EdgeInsets.all(10),
          color: Colors.blueGrey,
            height: 700,  width: 600,
           child: Column(
             children: <Widget>[
               Container(
                   margin: EdgeInsetsDirectional.only(top:120),
                   height:320, width:350,
                   
                 decoration: ShapeDecoration(
                    color: Colors.white,
                  shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.all( Radius.circular(20.0)),
                  
                ),
                ),
                   
                   child:  Column(
                    children: <Widget>[
                      Padding(padding: EdgeInsets.only(top:20),
                        child: Text("Uploaded Files", style: TextStyle(color: Colors.blue, fontSize: 20, fontWeight: FontWeight.bold),
                         textAlign: TextAlign.center,
                         
                      )
                      ),
                      Container(
                         color: Colors.blueAccent,
                          height:65,
                          margin: EdgeInsets.only(top: 20),
                          child: Row(
                              children: <Widget>[
                                Container(
                                  margin: EdgeInsetsDirectional.only(top:1.5, start:60, bottom: 1.5),
                                  height:50, width:200,
                   
                                  decoration: ShapeDecoration(
                                  color: Colors.white,
                                  shape: RoundedRectangleBorder(
                                   borderRadius: BorderRadius.all( Radius.circular(10.0)), ),
                              ),
                                child: Padding(padding: EdgeInsets.all(14),
                                    child:Text("Reasoning ability part2", style:
                                TextStyle(color: Colors.blue, fontSize:15, fontWeight: FontWeight.bold),
                                       textAlign: TextAlign.center,
                               )
                            ),
                                ),
                           Padding(
                             padding: const EdgeInsets.all(5.0),
                             child: Radio(
                                
                                  value: 'one',
                                 onChanged:null,
                                  groupValue: _radioValue,
                                  activeColor: Colors.white,
        
              ),
                           ),
                              ],
                          ),
                      ),
                  Container(
                  width:250, height:30,
                  alignment: Alignment(0.0, 0.0),
                  margin: EdgeInsets.only(top:20),
                  decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(100),
                  border: Border.all(color:Colors.blue, width:2.0)
              ),
              padding: EdgeInsets.only(top:10),
              child: TextField(
                textAlign: TextAlign.center,
                
                style: TextStyle(fontSize:10.0),
                 decoration: InputDecoration(
                  border: InputBorder.none,
                   hintText: 'Enter quantity',
                    hintStyle: TextStyle(fontSize:15.0, color: Colors.blue),
                ),
              ),
           ),
              Container(
                  width:250, height:30,
                  alignment: Alignment(0.0, 0.0),
                  margin: EdgeInsets.only(top:15),
                  decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(100),
                  border: Border.all(color:Colors.blue, width:2.0)
              ),
              padding: EdgeInsets.only(top:10),
              child: TextField(
                textAlign: TextAlign.center,
                
                style: TextStyle(fontSize:10.0),
                 decoration: InputDecoration(
                  border: InputBorder.none,
                   hintText: 'Enter address',
                   hintStyle: TextStyle(fontSize:15.0, color: Colors.blue),
                ),
                
              ),
           ),
             Padding(padding: EdgeInsets.only(top:20),
                child: Row(
                    children: <Widget>[
                         
                         Padding(
                           padding: const EdgeInsets.fromLTRB(100,10,0,0),
                           child: Text("To pay:", style: TextStyle(
                             fontSize:15, fontWeight:FontWeight.bold,color: Colors.blue), 
                                
                             ),
                         ),
                         Padding(
                           padding: const EdgeInsets.fromLTRB(50,10,0,0),
                           child: Text("Rs 35", style: TextStyle(
                             fontSize:15, fontWeight:FontWeight.bold,color: Colors.blue), 
                                
                             ),
                         )
                    ],

                ),

             )
                    ],
                )
               )
             ],

           ),      
            
            ),
           
             

           
        );
        


      
    
  }
}